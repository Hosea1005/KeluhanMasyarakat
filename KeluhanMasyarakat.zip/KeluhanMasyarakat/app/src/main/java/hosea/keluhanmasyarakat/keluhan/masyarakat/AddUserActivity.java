package hosea.keluhanmasyarakat.keluhan.masyarakat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import hosea.keluhanmasyarakat.R;
import hosea.keluhanmasyarakat.keluhan.RegisterAPI;
import hosea.keluhanmasyarakat.keluhan.Value;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AddUserActivity extends AppCompatActivity {
    public static final String URL = "http://192.168.43.44:80/";
    private ProgressDialog progress;
    private RadioButton radiostatus;

    @BindView(R.id.add_nama)
    EditText add_nama;
    @BindView(R.id.add_topik) EditText add_topik;
    @BindView(R.id.add_isi) EditText add_isi;
    @BindView(R.id.radiostatus)
    RadioGroup radioGroup;

    @OnClick(R.id.btn_submit) void insert(){

        progress = new ProgressDialog(this);
        progress.setCancelable(false);
        progress.setMessage("Loading...");
        progress.show();

        String nama = add_nama.getText().toString();
        String topik = add_topik.getText().toString();
        String isi = add_isi.getText().toString();

        int selectedId = radioGroup.getCheckedRadioButtonId();

        radiostatus = (RadioButton) findViewById(selectedId);
        String status = radiostatus.getText().toString();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RegisterAPI api = retrofit.create(RegisterAPI.class);
        Call<Value> call = api.daftar(nama, topik, isi, status);
        call.enqueue(new Callback<Value>() {
            @Override
            public void onResponse(Call<Value> call, Response<Value> response) {
                String value = response.body().getValue();
                String message = response.body().getMessage();
                progress.dismiss();
                if (value.equals("1")){
                    Toast.makeText(AddUserActivity.this, message, Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(AddUserActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Value> call, Throwable t) {
                progress.dismiss();
                Toast.makeText(AddUserActivity.this, "Jaringan error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @OnClick(R.id.btnview) void lihat(){
        startActivity(new Intent(AddUserActivity.this, ViewUserActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        ButterKnife.bind(this);
    }
}