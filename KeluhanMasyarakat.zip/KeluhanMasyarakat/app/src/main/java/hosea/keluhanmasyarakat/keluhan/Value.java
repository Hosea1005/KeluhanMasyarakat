package hosea.keluhanmasyarakat.keluhan;

import java.util.List;

public class Value {

    String value;
    String message;
    List<Result> result;

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }

    public List<Result> getResult() {
        return result;
    }
}
