package hosea.keluhanmasyarakat.room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Peraturan.class}, version = 1)
public abstract class PeraturanDatabase extends RoomDatabase {

    private static PeraturanDatabase instance;

    public abstract PeraturanDao peraturanDao();

    public static synchronized PeraturanDatabase getInstance(Context context){
        if (instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    PeraturanDatabase.class, "peraturan_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {

            super.onCreate(db);

            new PopulateDbAsyncTask(instance).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void>{
        private PeraturanDao peraturanDao;

        private PopulateDbAsyncTask(PeraturanDatabase db){
            peraturanDao = db.peraturanDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            peraturanDao.insert(new Peraturan("Sopan santun","Dalam penggunaan kata haruslah sopan",3));
            peraturanDao.insert(new Peraturan("HOAX","Dalam mengajukan pertanyaan haruslahlah berdasarkan fakta",5));
            peraturanDao.insert(new Peraturan("Kata kotor","Dilarang menggunakan kata-kata yang kasar",4));
            return null;
        }
    }
}
