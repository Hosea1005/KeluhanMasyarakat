package hosea.keluhanmasyarakat.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "peraturan_table")
public class Peraturan {

    @PrimaryKey(autoGenerate = true)
    public int idPeraturan;

    public String topik;

    public String isi;
    
    public int tingkat;

    public Peraturan(String topik, String isi, int tingkat) {
        this.topik = topik;
        this.isi = isi;
        this.tingkat = tingkat;
    }

    public void setIdPeraturan(int idPeraturan) {
        this.idPeraturan = idPeraturan;
    }

    public int getIdPeraturan() {
        return idPeraturan;
    }

    public String getTopik() {
        return topik;
    }

    public String getIsi() {
        return isi;
    }

    public int getTingkat() {
        return tingkat;
    }
}
