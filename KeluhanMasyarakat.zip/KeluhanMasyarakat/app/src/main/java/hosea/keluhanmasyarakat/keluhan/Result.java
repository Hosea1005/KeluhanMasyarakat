package hosea.keluhanmasyarakat.keluhan;

public class Result {

    String nama ;
    String topik;
    String isi;
    String status;

    public String getNama() {
        return nama;
    }

    public String getTopik() {
        return topik;
    }

    public String getIsi() {
        return isi;
    }

    public String getStatus() {
        return status;
    }
}
