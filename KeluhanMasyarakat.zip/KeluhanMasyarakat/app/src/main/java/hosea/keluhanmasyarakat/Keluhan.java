package hosea.keluhanmasyarakat;

import com.google.gson.annotations.SerializedName;

public class Keluhan {

    @SerializedName("idkeluh")
    private int idkeluh;
    @SerializedName("isikeluh")
    private String isikeluh;
    @SerializedName("datekeluh")
    private String datekeluh;
    @SerializedName("topikkeluh")
    private String topikkeluh;
    @SerializedName("namakeluh")
    private String namakeluh;
    @SerializedName("lokasikeluh")
    private String lokasikeluh;
    @SerializedName("foto")
    private String foto;
    @SerializedName("love")
    private boolean love;
    @SerializedName("value")
    private String value;
    @SerializedName("message")
    private String massage;

    public int getIdkeluh() {
        return idkeluh;
    }

    public void setIdkeluh(int idkeluh) {
        this.idkeluh = idkeluh;
    }

    public String getIsikeluh() {
        return isikeluh;
    }

    public void setIsikeluh(String isikeluh) {
        this.isikeluh = isikeluh;
    }

    public String getDatekeluh() {
        return datekeluh;
    }

    public void setDatekeluh(String datekeluh) {
        this.datekeluh = datekeluh;
    }

    public String getTopikkeluh() {
        return topikkeluh;
    }

    public void setTopikkeluh(String topikkeluh) {
        this.topikkeluh = topikkeluh;
    }

    public String getNamakeluh() {
        return namakeluh;
    }

    public void setNamakeluh(String namakeluh) {
        this.namakeluh = namakeluh;
    }

    public String getLokasikeluh() {
        return lokasikeluh;
    }

    public void setLokasikeluh(String lokasikeluh) {
        this.lokasikeluh = lokasikeluh;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public boolean isLove() {
        return love;
    }

    public void setLove(boolean love) {
        this.love = love;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getMassage() {
        return massage;
    }

    public void setMassage(String massage) {
        this.massage = massage;
    }
}
