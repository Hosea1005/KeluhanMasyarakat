package hosea.keluhanmasyarakat.Models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AccountModel {
    @Expose
    @SerializedName("username")
    private String username;

    @Expose
    @SerializedName("nohp")
    private String nohp;

    @Expose
    @SerializedName("password")
    private String password;

    @Expose
    @SerializedName("success")
    private boolean succes;

    @Expose
    @SerializedName("message")
    private String message;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNohp() {
        return nohp;
    }

    public void setNohp(String nohp) {
        this.nohp = nohp;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isSucces() {
        return succes;
    }

    public void setSucces(boolean succes) {
        this.succes = succes;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
