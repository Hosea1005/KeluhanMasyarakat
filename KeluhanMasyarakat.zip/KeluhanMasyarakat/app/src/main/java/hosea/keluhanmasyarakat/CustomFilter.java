package hosea.keluhanmasyarakat;

import android.widget.Filter;

import java.util.ArrayList;

import hosea.keluhanmasyarakat.autentikasiUser.Adapter;

public class CustomFilter extends Filter {
    Adapter adapter;
    ArrayList<Keluhan> filterList;

    public CustomFilter(ArrayList<Keluhan> filterList,Adapter adapter)
    {
        this.adapter=adapter;
        this.filterList=filterList;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results=new FilterResults();
        if(constraint != null && constraint.length() > 0)
        {
            //CHANGE TO UPPER
            constraint=constraint.toString().toUpperCase();
            //STORE OUR FILTERED PLAYERS
            ArrayList<Keluhan> filteredPets=new ArrayList<>();

            for (int i=0;i<filterList.size();i++)
            {
                //CHECK
                if(filterList.get(i).getTopikkeluh().toUpperCase().contains(constraint))
                {
                    //ADD PLAYER TO FILTERED PLAYERS
                    filteredPets.add(filterList.get(i));
                }
            }

            results.count=filteredPets.size();
            results.values=filteredPets;

        }else
        {
            results.count=filterList.size();
            results.values=filterList;
        }

        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
//        adapter.keluhans =(ArrayList<Keluhan>) results.values;
        adapter.notifyDataSetChanged();
    }
}
