package hosea.keluhanmasyarakat.room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PeraturanDao {

    @Insert
    void insert(Peraturan peraturan);

    @Update
    void update(Peraturan peraturan);

    @Delete
    void delete(Peraturan peraturan);

    @Query("DELETE FROM peraturan_table")
    void deleteAllPeraturan();

    @Query("SELECT * FROM peraturan_table ORDER BY tingkat DESC")
    LiveData<List<Peraturan>> getAllPeraturan();
}
