package hosea.keluhanmasyarakat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.sdsmdg.tastytoast.TastyToast;

import hosea.keluhanmasyarakat.contenProv.KomentarActivity;
import hosea.keluhanmasyarakat.keluhan.masyarakat.ViewUserActivity;
import hosea.keluhanmasyarakat.room.PeraturanUserActivity;

public class UtamaActivity extends AppCompatActivity {
    RelativeLayout rv1,rv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utama);
        rv1 = findViewById(R.id.rv1);
        rv2 = findViewById(R.id.rv2);

        rv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UtamaActivity.this, KomentarActivity.class));
                TastyToast.makeText(getApplicationContext(), "Catatan kamu ", 5000, TastyToast.SUCCESS);
            }
        });
        rv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UtamaActivity.this, ViewUserActivity.class));
                TastyToast.makeText(getApplicationContext(), "Ayo mulai keluhan", 5000, TastyToast.SUCCESS);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_user,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.peraturan:
                Toast.makeText(this, "Peraturan", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(UtamaActivity.this, PeraturanUserActivity.class));
                return true;
            case R.id.logout:
                Toast.makeText(this, "Terima kasih sudah login", Toast.LENGTH_SHORT).show();
                finish();
                return true;
            case R.id.about:
                Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(UtamaActivity.this, About.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
