package hosea.keluhanmasyarakat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import hosea.keluhanmasyarakat.berita.MainActivity;

public class AdminActivity extends AppCompatActivity {
    Button manage, back;
    Switch ck;
    TextView as;
    String CLOSEADMIN = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        manage = findViewById(R.id.btnManage);
        ck = findViewById(R.id.hide);
        as = findViewById(R.id.as);


        ck.setChecked(false);
        manage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if (ck.isChecked()){
                as.setText("on");
                String nilai = "a";
                Intent intent = new Intent(AdminActivity.this, MainActivity.class);
                startActivity(intent);
            }
            if (ck.isChecked() == false){
//                as.setText("off");
//                String nilai = "b";
                Intent intent = new Intent(AdminActivity.this, MainActivity.class);
//                intent.putExtra("nilaia",nilai);
                startActivity(intent);
            }
            }
        });
    }

}
