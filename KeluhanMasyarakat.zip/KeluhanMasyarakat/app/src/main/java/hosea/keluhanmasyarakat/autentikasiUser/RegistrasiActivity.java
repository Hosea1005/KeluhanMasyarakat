package hosea.keluhanmasyarakat.autentikasiUser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import hosea.keluhanmasyarakat.Models.AccountModel;
import hosea.keluhanmasyarakat.R;
import hosea.keluhanmasyarakat.Retrofit.ApiClient;
import hosea.keluhanmasyarakat.Retrofit.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegistrasiActivity extends AppCompatActivity {
    EditText edit_username, edt_password, edt_cfrm_password, edt_nohp;
    ApiInterface apiInterface;
    int noa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrasi);
        edit_username = findViewById(R.id.ed_regist_username);
        edt_nohp = findViewById(R.id.ed_regist_nohp);
        edt_password =findViewById(R.id.ed_regist_password);
        edt_cfrm_password = findViewById(R.id.ed_regist_confirm_password);
        apiInterface = ApiClient.getAplication().create(ApiInterface.class);

    }

    public void registerUserRegist(View v){
        Call<AccountModel> callRegister = apiInterface.registerUser(
                edit_username.getText().toString(),
                noa = Integer.parseInt(edt_nohp.getText().toString()),
                edt_password.getText().toString());

        callRegister.enqueue(new Callback<AccountModel>() {
            @Override
            public void onResponse(Call<AccountModel> call, Response<AccountModel> response) {
                if (response.isSuccessful() && response.body() != null){
                    AccountModel accountModel = response.body();
                    if (accountModel.isSucces()){
                        Toast.makeText(RegistrasiActivity.this, "User registered succesfully", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(RegistrasiActivity.this, "User couldn't be registered", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<AccountModel> call, Throwable t) {
                startActivity(new Intent(RegistrasiActivity.this, LoginActivity.class));
            }
        });
    }
}
