package hosea.keluhanmasyarakat.room;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import hosea.keluhanmasyarakat.R;

public class PeraturanActivity extends AppCompatActivity {
    private PeraturanViewModel peraturanViewModel;
    public static final int ADD_PERATURAN_REQUEST = 1;
    FloatingActionButton floatingActionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peraturan);
        floatingActionButton = findViewById(R.id.fb_add_peraturan);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PeraturanActivity.this, AddPeraturanActivity.class);
                startActivityForResult(intent,ADD_PERATURAN_REQUEST);
            }
        });
        RecyclerView recyclerView = findViewById(R.id.rvPeraturan);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        final PeraturanAdapter adapter = new PeraturanAdapter();
        recyclerView.setAdapter(adapter);
        peraturanViewModel = ViewModelProviders.of(this).get(PeraturanViewModel.class);
        peraturanViewModel.getAllPeraturan().observe(this, new Observer<List<Peraturan>>() {
            @Override
            public void onChanged(List<Peraturan> peraturans) {
                adapter.setPeraturans(peraturans);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                peraturanViewModel.delete(adapter.getPeraturanAt(viewHolder.getAdapterPosition()));
                Toast.makeText(PeraturanActivity.this, "Peraturan telah di hapus", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_PERATURAN_REQUEST &&  resultCode == RESULT_OK){
            String topik = data.getStringExtra(AddPeraturanActivity.EXTRA_TOPIK);
            String keterangan = data.getStringExtra(AddPeraturanActivity.EXTRA_KETERANGAN);
            int tingkat = data.getIntExtra(AddPeraturanActivity.EXTRA_TINGKAT,1);

            Peraturan peraturan = new Peraturan(topik,keterangan,tingkat);
            peraturanViewModel.insert(peraturan);
            Toast.makeText(this, "Peraturan ditambahkan", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Peraturan gagal ditambahkan", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.delete_peraturan,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete_all_peraturan:
                peraturanViewModel.deleteAllPeraturan();
                Toast.makeText(this, "All notes deleted", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
