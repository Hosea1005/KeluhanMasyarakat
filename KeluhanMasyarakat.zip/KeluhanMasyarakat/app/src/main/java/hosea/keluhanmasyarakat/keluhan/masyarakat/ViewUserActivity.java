package hosea.keluhanmasyarakat.keluhan.masyarakat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import hosea.keluhanmasyarakat.About;
import hosea.keluhanmasyarakat.R;
import hosea.keluhanmasyarakat.hms.GoScan;
import hosea.keluhanmasyarakat.hms.ScanActivity;
import hosea.keluhanmasyarakat.keluhan.AddActivity;
import hosea.keluhanmasyarakat.keluhan.RegisterAPI;
import hosea.keluhanmasyarakat.keluhan.Result;
import hosea.keluhanmasyarakat.keluhan.Value;
import hosea.keluhanmasyarakat.room.PeraturanActivity;
import hosea.keluhanmasyarakat.room.PeraturanUserActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ViewUserActivity extends AppCompatActivity {
    public static final String URL = "http://192.168.43.44:80/";
    private List<Result> results = new ArrayList<>();
    private RecyclerViewAdap viewAdap;
    FloatingActionButton fb;

    @BindView(R.id.recycler)
    RecyclerView recycler;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user);
        fb = findViewById(R.id.btn_add_keluan);
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ViewUserActivity.this, AddActivity.class));
            }
        });
        ButterKnife.bind(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Daftar Keluhan");

        viewAdap = new RecyclerViewAdap(this, results);
        RecyclerView.LayoutManager mlayoutManager = new LinearLayoutManager(getApplicationContext());
        recycler.setLayoutManager(mlayoutManager);
        recycler.setItemAnimator(new DefaultItemAnimator());
        recycler.setAdapter(viewAdap);

        loadData();
    }


    @Override
    protected void onResume(){
        super.onResume();
        loadData();
    }

    private  void loadData(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RegisterAPI api = retrofit.create(RegisterAPI.class);
        Call<Value> call = api.lihat();
        call.enqueue(new Callback<Value>() {
            @Override
            public void onResponse(Call<Value> call, Response<Value> response) {
                String value = response.body().getValue();
                progressBar.setVisibility(View.GONE);
                if (value.equals("1")){
                    results = response.body().getResult();
                    viewAdap = new RecyclerViewAdap(ViewUserActivity.this, results);
                    recycler.setAdapter(viewAdap);
                }
            }

            @Override
            public void onFailure(Call<Value> call, Throwable t) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_user,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.peraturan:
                Toast.makeText(this, "Peraturan", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(ViewUserActivity.this, PeraturanUserActivity.class));
                return true;
            case R.id.logout:
                Toast.makeText(this, "Terima kasih sudah login", Toast.LENGTH_SHORT).show();
                finish();
                return true;
            case R.id.about:
                Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(ViewUserActivity.this, About.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}