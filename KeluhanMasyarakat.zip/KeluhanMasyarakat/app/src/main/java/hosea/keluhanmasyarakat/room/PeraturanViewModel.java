package hosea.keluhanmasyarakat.room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class PeraturanViewModel extends AndroidViewModel {
    private PeraturanRepository repository;
    private LiveData<List<Peraturan>> allPeraturan;

    public PeraturanViewModel(@NonNull Application application) {
        super(application);
        repository = new PeraturanRepository(application);
        allPeraturan = repository.getAllPeraturan();
    }

    public void insert(Peraturan peraturan){
        repository.insert(peraturan);
    }

    public void update(Peraturan peraturan){
        repository.update(peraturan);
    }

    public void delete(Peraturan peraturan){
        repository.delete(peraturan);
    }

    public void deleteAllPeraturan(){
        repository.deleteAllPeraturan();
    }

    public LiveData<List<Peraturan>> getAllPeraturan() {
        return allPeraturan;
    }
}
