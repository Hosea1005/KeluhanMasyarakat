package hosea.keluhanmasyarakat.room;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import hosea.keluhanmasyarakat.R;

public class AddPeraturanActivity extends AppCompatActivity {
    public static final String EXTRA_TOPIK =
            "hosea.keluhanmasyarakat.room.EXTRA_TOPIK";
    public static final String EXTRA_KETERANGAN =
            "hosea.keluhanmasyarakat.room.EXTRA_KETERANGAN";
    public static final String EXTRA_TINGKAT =
            "hosea.keluhanmasyarakat.room.EXTRA_TINGKAT";

    private EditText edtTopik, edtKeterangan;
    private NumberPicker npTingkat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_peraturan);
        edtTopik = findViewById(R.id.edt_text_topik);
        edtKeterangan = findViewById(R.id.edt_text_keterangan);
        npTingkat = findViewById(R.id.number_picker_tingkat);

        npTingkat.setMinValue(1);
        npTingkat.setMaxValue(10);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);
        setTitle("Add Peraturan");
    }

    private void savePeraturan(){
        String topik = edtTopik.getText().toString();
        String keterangan = edtKeterangan.getText().toString();
        int tingkat = npTingkat.getValue();

        if (topik.trim().isEmpty() || keterangan.trim().isEmpty()){
            Toast.makeText(this, "Tolong di isi dengan lengkap", Toast.LENGTH_SHORT).show();
        }

        Intent data = new Intent();
        data.putExtra(EXTRA_TOPIK,topik);
        data.putExtra(EXTRA_KETERANGAN,keterangan);
        data.putExtra(EXTRA_TINGKAT,tingkat);

        setResult(RESULT_OK,data);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_peraturan_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_note:
                savePeraturan();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
