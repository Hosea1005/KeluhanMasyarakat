package hosea.keluhanmasyarakat.room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class PeraturanRepository {
    private PeraturanDao peraturanDao;
    private LiveData<List<Peraturan>> allPeraturan;

    public PeraturanRepository(Application application){
        PeraturanDatabase database = PeraturanDatabase.getInstance(application);
        peraturanDao = database.peraturanDao();
        allPeraturan = peraturanDao.getAllPeraturan();
    }

    public void insert(Peraturan peraturan){
        new InsertPeraturanAsyncTask(peraturanDao).execute(peraturan);
    }

    public void update(Peraturan peraturan){
        new UpdatetPeraturanAsyncTask(peraturanDao).execute(peraturan);
    }

    public void delete(Peraturan peraturan){
        new DeletePeraturanAsyncTask(peraturanDao).execute(peraturan);
    }

    public void deleteAllPeraturan(){
        new DeleteAllPeraturanAsyncTask(peraturanDao).execute();
    }

    public LiveData<List<Peraturan>> getAllPeraturan() {
        return allPeraturan;
    }

    public static class InsertPeraturanAsyncTask extends AsyncTask<Peraturan, Void, Void>{
        private PeraturanDao peraturanDao;

        public InsertPeraturanAsyncTask(PeraturanDao peraturanDao) {
            this.peraturanDao = peraturanDao;
        }

        @Override
        protected Void doInBackground(Peraturan... peraturans) {
            peraturanDao.insert(peraturans[0]);
            return null;
        }
    }

    public static class UpdatetPeraturanAsyncTask extends AsyncTask<Peraturan, Void, Void>{
        private PeraturanDao peraturanDao;

        public UpdatetPeraturanAsyncTask(PeraturanDao peraturanDao) {
            this.peraturanDao = peraturanDao;
        }

        @Override
        protected Void doInBackground(Peraturan... peraturans) {
            peraturanDao.update(peraturans[0]);
            return null;
        }
    }

    public static class DeletePeraturanAsyncTask extends AsyncTask<Peraturan, Void, Void>{
        private PeraturanDao peraturanDao;

        public DeletePeraturanAsyncTask(PeraturanDao peraturanDao) {
            this.peraturanDao = peraturanDao;
        }

        @Override
        protected Void doInBackground(Peraturan... peraturans) {
            peraturanDao.delete(peraturans[0]);
            return null;
        }
    }

    public static class DeleteAllPeraturanAsyncTask extends AsyncTask<Void, Void, Void>{
        private PeraturanDao peraturanDao;

        public DeleteAllPeraturanAsyncTask(PeraturanDao peraturanDao) {
            this.peraturanDao = peraturanDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            peraturanDao.deleteAllPeraturan();
            return null;
        }
    }
}
