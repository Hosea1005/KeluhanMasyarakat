package hosea.keluhanmasyarakat.keluhan;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface RegisterAPI {

    @FormUrlEncoded
    @POST("/Project/insert.php")
    Call<Value> daftar(@Field("nama") String nama,
                       @Field("topik") String topik,
                       @Field("isi") String isi,
                       @Field("status") String status);

    @GET("/Project/view.php")
    Call<Value> view();

    @FormUrlEncoded
    @POST("/Project/update.php")
    Call<Value> ubah(@Field("nama") String nama,
                     @Field("topik") String topik,
                     @Field("isi") String isi,
                     @Field("status") String status);

    @FormUrlEncoded
    @POST("/Project/delete.php")
    Call<Value> hapus(@Field("nama") String nama);

    @FormUrlEncoded
    @POST("/Project/tambah.php")
    Call<Value> insert(@Field("nama") String nama,
                       @Field("topik") String topik,
                       @Field("isi") String isi);

    @GET("/Project/lihat.php")
    Call<Value> lihat();

}
