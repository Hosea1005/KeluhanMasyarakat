package hosea.keluhanmasyarakat.autentikasiUser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.sdsmdg.tastytoast.TastyToast;

import hosea.keluhanmasyarakat.Models.AccountModel;
import hosea.keluhanmasyarakat.R;
import hosea.keluhanmasyarakat.Retrofit.ApiClient;
import hosea.keluhanmasyarakat.Retrofit.ApiInterface;
import hosea.keluhanmasyarakat.UtamaActivity;
import hosea.keluhanmasyarakat.keluhan.masyarakat.ViewUserActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    ApiInterface apiInterface;
    EditText login_username, login_passowrd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login_username = findViewById(R.id.ed_login_username);
        login_passowrd = findViewById(R.id.edt_login_password);
        apiInterface = ApiClient.getAplication().create(ApiInterface.class);
    }

    public void loginUser(View v){
        Call<AccountModel> accountModelCall = apiInterface.loginUser(login_username.getText().toString(),
                login_passowrd.getText().toString());

        accountModelCall.enqueue(new Callback<AccountModel>() {
            @Override
            public void onResponse(Call<AccountModel> call, Response<AccountModel> response) {
                if (response.body() != null){
                    AccountModel accountModel = response.body();

                    if (accountModel.isSucces()){

                        if (login_username.getText().toString().equals("hosea") && login_passowrd.getText().toString().equals("hosea123")){
                            TastyToast.makeText(getApplicationContext(), "Maaf akun " +login_username.getText().toString() + " terdaftar sebagai admin.", 5000, TastyToast.WARNING);
                        }
                        else {
                            TastyToast.makeText(getApplicationContext(), "Hallo "+login_username.getText().toString(), 5000, TastyToast.SUCCESS);
                            startActivity(new Intent(LoginActivity.this, UtamaActivity.class));
                        }
                    }


                    else {
                        TastyToast.makeText(getApplicationContext(), "Maaf akun " +login_username.getText().toString()+" tidak terdaftar.", 5000, TastyToast.WARNING);
                    }
                }
            }

            @Override
            public void onFailure(Call<AccountModel> call, Throwable t) {
                Toast.makeText(LoginActivity.this, "Error", Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void registerUser(View v){
        Intent intent= new Intent(LoginActivity.this, RegistrasiActivity.class);
        startActivity(intent);
    }
}
