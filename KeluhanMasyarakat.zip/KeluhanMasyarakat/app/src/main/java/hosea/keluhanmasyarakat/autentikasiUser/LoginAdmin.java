package hosea.keluhanmasyarakat.autentikasiUser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.sdsmdg.tastytoast.TastyToast;

import hosea.keluhanmasyarakat.Models.AccountModel;
import hosea.keluhanmasyarakat.R;
import hosea.keluhanmasyarakat.Retrofit.ApiClient;
import hosea.keluhanmasyarakat.Retrofit.ApiInterface;
import hosea.keluhanmasyarakat.keluhan.ViewActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginAdmin extends AppCompatActivity {

    ApiInterface apiInterface;
    EditText login_username, login_passowrd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_admin);
        login_username = findViewById(R.id.ed_login_username);
        login_passowrd = findViewById(R.id.edt_login_password);
        apiInterface = ApiClient.getAplication().create(ApiInterface.class);
    }
    public void loginAdmin(View v){
        Call<AccountModel> accountModelCall = apiInterface.loginAdmin(login_username.getText().toString(),
                login_passowrd.getText().toString());

        accountModelCall.enqueue(new Callback<AccountModel>() {
            @Override
            public void onResponse(Call<AccountModel> call, Response<AccountModel> response) {
                if (response.body() != null){
                    AccountModel accountModel = response.body();

                    if (accountModel.isSucces()){

                        if (login_username.getText().toString().equals("hosea") && login_passowrd.getText().toString().equals("hosea123")){
                            TastyToast.makeText(getApplicationContext(), "Hallo "+login_username.getText().toString() + "Sebagai admin.", 5000, TastyToast.SUCCESS);
                            startActivity(new Intent(LoginAdmin.this, ViewActivity.class));
                        }
                        else {
                            TastyToast.makeText(getApplicationContext(), "Maaf akun " +login_username.getText().toString() + " terdaftar sebagai user biasa.", 5000, TastyToast.WARNING);
                        }
                    }


                    else {
                        Toast.makeText(LoginAdmin.this, "User not found", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<AccountModel> call, Throwable t) {
                Toast.makeText(LoginAdmin.this, "Error", Toast.LENGTH_SHORT).show();

            }
        });
    }
}