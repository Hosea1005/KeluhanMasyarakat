package hosea.keluhanmasyarakat.keluhan.masyarakat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import hosea.keluhanmasyarakat.R;
import hosea.keluhanmasyarakat.keluhan.Result;

public class RecyclerViewAdap extends RecyclerView.Adapter<RecyclerViewAdap.ViewHolder> {


    private Context context;
    private List<Result> results;

    public RecyclerViewAdap(Context context, List<Result> results){
        this.context = context;
        this.results = results;
    }


    @Override
    public RecyclerViewAdap.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_view_user, parent, false);
        RecyclerViewAdap.ViewHolder holder = new RecyclerViewAdap.ViewHolder(v);

        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewAdap.ViewHolder holder, int position) {
        Result result = results.get(position);
        holder.textViewNama.setText(result.getNama());
        holder.textViewTopik.setText(result.getTopik());
        holder.textViewIsi.setText(result.getIsi());
        holder.textViewStatus.setText(result.getStatus());
    }

    @Override
    public int getItemCount() {
        return results.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {

        @BindView(R.id.nama) TextView textViewNama;
        @BindView(R.id.topik) TextView textViewTopik;
        @BindView(R.id.isi) TextView textViewIsi;
        @BindView(R.id.status) TextView textViewStatus;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }

    }

}
