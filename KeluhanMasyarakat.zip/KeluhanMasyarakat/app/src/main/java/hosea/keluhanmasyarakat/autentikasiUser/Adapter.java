package hosea.keluhanmasyarakat.autentikasiUser;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hosea.keluhanmasyarakat.CustomFilter;
import hosea.keluhanmasyarakat.Keluhan;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> implements Filterable {
    List<Keluhan> keluhans,keluhanFilter;
    private Context context;
    private RecyclerViewClickListener mListener;
    CustomFilter filter;

    public Adapter(List<Keluhan> keluhans, Context context, RecyclerViewClickListener mListener) {
        this.keluhans =keluhans;
        this.keluhanFilter = keluhans;
        this.context = context;
        this.mListener = mListener;
    }

    @Override
    public Filter getFilter() {
        return null;
    }

    @NonNull
    @Override
    public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.MyViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
    public interface RecyclerViewClickListener {
        void onRowClick(View view, int position);
        void onLoveClick(View view, int position);
    }
}

