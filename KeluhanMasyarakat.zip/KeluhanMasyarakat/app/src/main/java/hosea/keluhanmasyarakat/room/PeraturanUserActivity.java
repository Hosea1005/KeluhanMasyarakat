package hosea.keluhanmasyarakat.room;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

import hosea.keluhanmasyarakat.R;

public class PeraturanUserActivity extends AppCompatActivity {
    private PeraturanViewModel peraturanViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peraturan_user);
        RecyclerView recyclerView = findViewById(R.id.rvPeraturanUser);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        final PeraturanAdapter adapter = new PeraturanAdapter();
        recyclerView.setAdapter(adapter);
        peraturanViewModel = ViewModelProviders.of(this).get(PeraturanViewModel.class);
        peraturanViewModel.getAllPeraturan().observe(this, new Observer<List<Peraturan>>() {
            @Override
            public void onChanged(List<Peraturan> peraturans) {
                adapter.setPeraturans(peraturans);
            }
        });
    }
}
