package hosea.keluhanmasyarakat.room;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import hosea.keluhanmasyarakat.R;

public class PeraturanAdapter extends RecyclerView.Adapter<PeraturanAdapter.PeraturanHolder> {
    private List<Peraturan> peraturans = new ArrayList<>();

    @NonNull
    @Override
    public PeraturanHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.peraturan_item, parent, false);
        return new PeraturanHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PeraturanHolder holder, int position) {
        Peraturan currentPeraturan = peraturans.get(position);
        holder.tvTopik.setText(currentPeraturan.getTopik());
        holder.tvKeterangan.setText(currentPeraturan.getIsi());
        holder.tvTingkat.setText(String.valueOf(currentPeraturan.getTingkat()));
    }

    @Override
    public int getItemCount() {
        return peraturans.size();
    }
    public Peraturan getPeraturanAt(int position){
        return peraturans.get(position);
    }

    public void setPeraturans(List<Peraturan> peraturans){
        this.peraturans = peraturans;
        this.notifyDataSetChanged();
    }

    public class PeraturanHolder extends RecyclerView.ViewHolder {
        private TextView tvTopik,tvKeterangan,tvTingkat;
        public PeraturanHolder(@NonNull View itemView) {
            super(itemView);
                tvTopik = itemView.findViewById(R.id.text_view_topik);
                tvKeterangan = itemView.findViewById(R.id.text_view_keterangan);
                tvTingkat = itemView.findViewById(R.id.text_view_tingkat);
        }
    }
}
