package hosea.keluhanmasyarakat.Retrofit;

import hosea.keluhanmasyarakat.Models.AccountModel;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {
    @FormUrlEncoded
    @POST("loginuser.php")
    Call<AccountModel> loginUser(@Field("username") String username, @Field("password") String password);

    @FormUrlEncoded
    @POST("loginadmin.php")
    Call<AccountModel> loginAdmin(@Field("username") String username, @Field("password") String password);


    @FormUrlEncoded
    @POST("registeruser.php")
    Call<AccountModel> registerUser(@Field("username") String username,
                                    @Field("nohp") int nohp,
                                    @Field("password") String password
                                    );


}
